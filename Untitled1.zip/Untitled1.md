```python
import pandas as pd
```


```python
df= pd.read_csv('AusApparalSales4thQrt2020.csv')
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Time</th>
      <th>State</th>
      <th>Group</th>
      <th>Unit</th>
      <th>Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1-Oct-2020</td>
      <td>Morning</td>
      <td>WA</td>
      <td>Kids</td>
      <td>8</td>
      <td>20000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1-Oct-2020</td>
      <td>Morning</td>
      <td>WA</td>
      <td>Men</td>
      <td>8</td>
      <td>20000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1-Oct-2020</td>
      <td>Morning</td>
      <td>WA</td>
      <td>Women</td>
      <td>4</td>
      <td>10000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1-Oct-2020</td>
      <td>Morning</td>
      <td>WA</td>
      <td>Seniors</td>
      <td>15</td>
      <td>37500</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1-Oct-2020</td>
      <td>Afternoon</td>
      <td>WA</td>
      <td>Kids</td>
      <td>3</td>
      <td>7500</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.isna().sum()
```




    Date     0
    Time     0
    State    0
    Group    0
    Unit     0
    Sales    0
    dtype: int64




```python
print((df['Unit']<0).sum(),'negative units')
```

    0 negative units
    


```python
print((df['Sales']<0).sum(),'negative sales')
```

    0 negative sales
    


```python
# Drop rows with missing values (if any)
df_cleaned = df.dropna()
print(df_cleaned)
```

                 Date        Time State     Group  Unit  Sales
    0      1-Oct-2020     Morning    WA      Kids     8  20000
    1      1-Oct-2020     Morning    WA       Men     8  20000
    2      1-Oct-2020     Morning    WA     Women     4  10000
    3      1-Oct-2020     Morning    WA   Seniors    15  37500
    4      1-Oct-2020   Afternoon    WA      Kids     3   7500
    ...           ...         ...   ...       ...   ...    ...
    7555  30-Dec-2020   Afternoon   TAS   Seniors    14  35000
    7556  30-Dec-2020     Evening   TAS      Kids    15  37500
    7557  30-Dec-2020     Evening   TAS       Men    15  37500
    7558  30-Dec-2020     Evening   TAS     Women    11  27500
    7559  30-Dec-2020     Evening   TAS   Seniors    13  32500
    
    [7560 rows x 6 columns]
    


```python
from sklearn.preprocessing import MinMaxScaler
```


```python
df_normalized= df.copy()
print(df_normalized)
```

                 Date        Time State     Group  Unit  Sales
    0      1-Oct-2020     Morning    WA      Kids     8  20000
    1      1-Oct-2020     Morning    WA       Men     8  20000
    2      1-Oct-2020     Morning    WA     Women     4  10000
    3      1-Oct-2020     Morning    WA   Seniors    15  37500
    4      1-Oct-2020   Afternoon    WA      Kids     3   7500
    ...           ...         ...   ...       ...   ...    ...
    7555  30-Dec-2020   Afternoon   TAS   Seniors    14  35000
    7556  30-Dec-2020     Evening   TAS      Kids    15  37500
    7557  30-Dec-2020     Evening   TAS       Men    15  37500
    7558  30-Dec-2020     Evening   TAS     Women    11  27500
    7559  30-Dec-2020     Evening   TAS   Seniors    13  32500
    
    [7560 rows x 6 columns]
    


```python
scaler = MinMaxScaler()
df_normalized[['Unit', 'Sales']] = scaler.fit_transform(df[['Unit', 'Sales']])

df_normalized.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Time</th>
      <th>State</th>
      <th>Group</th>
      <th>Unit</th>
      <th>Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1-Oct-2020</td>
      <td>Morning</td>
      <td>WA</td>
      <td>Kids</td>
      <td>0.095238</td>
      <td>0.095238</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1-Oct-2020</td>
      <td>Morning</td>
      <td>WA</td>
      <td>Men</td>
      <td>0.095238</td>
      <td>0.095238</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1-Oct-2020</td>
      <td>Morning</td>
      <td>WA</td>
      <td>Women</td>
      <td>0.031746</td>
      <td>0.031746</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1-Oct-2020</td>
      <td>Morning</td>
      <td>WA</td>
      <td>Seniors</td>
      <td>0.206349</td>
      <td>0.206349</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1-Oct-2020</td>
      <td>Afternoon</td>
      <td>WA</td>
      <td>Kids</td>
      <td>0.015873</td>
      <td>0.015873</td>
    </tr>
  </tbody>
</table>
</div>




```python
stae_sales=df.groupby('State')['Sales'].sum()
print(state_sales)
```

    State
    VIC    105565000
    NSW     74970000
    SA      58857500
    QLD     33417500
    TAS     22760000
    NT      22580000
    WA      22152500
    Name: Sales, dtype: int64
    


```python
state_unites=df.groupby('State')['Unit'].sum()
print(state_unites)
```

    State
    NSW    29988
    NT      9032
    QLD    13367
    SA     23543
    TAS     9104
    VIC    42226
    WA      8861
    Name: Unit, dtype: int64
    


```python
group_sales = df.groupby('Group')['Sales'].sum()
print(group_sales)
```

    Group
    Kids       85072500
    Men        85750000
    Seniors    84037500
    Women      85442500
    Name: Sales, dtype: int64
    


```python
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
# Revenue by State
plt.figure(figsize=(10,6))
sns.barplot(x=state_sales.index, y=state_sales.values, palette="viridis")
plt.title('Total Sales by State')
plt.ylabel('Sales')
plt.xticks(rotation=45)
plt.show()
```

    C:\Users\lenovo\AppData\Local\Temp\ipykernel_24944\1929962513.py:3: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x=state_sales.index, y=state_sales.values, palette="viridis")
    


    
![png](output_13_1.png)
    



```python
plt.figure(figsize=(8,5))
sns.barplot(x=group_sales.index,y=group_sales.values,palette="pastel")
plt.title('Total sales by group')
plt.ylabel('sales')
plt.xticks(rotation=10)
plt.show()          
           
```

    C:\Users\lenovo\AppData\Local\Temp\ipykernel_24944\923046281.py:2: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x=group_sales.index,y=group_sales.values,palette="pastel")
    


    
![png](output_14_1.png)
    



```python
# Heatmap of sales by state and group
pivot_table = df.pivot_table(values='Sales', index='State', columns='Group', aggfunc='sum')
plt.figure(figsize=(10,6))
sns.heatmap(pivot_table, annot=True, fmt='.0f', cmap='YlGnBu')
plt.title('Sales by State and Customer Group')
plt.show()
```


    
![png](output_15_0.png)
    



```python

```
